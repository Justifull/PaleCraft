# Honied - A Minecraft Texturepack

## Get the Texturepack
1. Go to [Releases](https://github.com/Justifull/Honied/releases)
2. Download the latest `Honied-X.XX.X.zip` file
3. Paste the file into your `resourcepacks` folder

## Find your `resourcepacks` folder
### On Windows
1. Go to Explorer
2. Enter the following into the `path` field & press <kbd>⏎ Enter</kbd>:
```bash
%appdata%
```
3. Go into your `.minecraft` folder
4. There you find it!

### On MacOs
> COMING SOON..